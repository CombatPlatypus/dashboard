// MÁSCARA PARA INPUTS

const regex = /[^ 0-9a-zA-ZÀÈÌÒÙÁÉÍÓÚÂÊÎÔÛÃÕÇàèìòùáéíóúâêîôûãõç\b@?!#$%():.,/]/g;

function applyInputFilter() {
    document.querySelectorAll('input, textarea').forEach(element => {
        element.removeEventListener('input', filterInput);
        element.addEventListener('input', filterInput);
    });
}

function filterInput(event) {
    event.target.value = event.target.value.replace(regex, '');
}

applyInputFilter();

// FORÇAR MAXLENGTH

$('input[maxlength], textarea[maxlength]').on('input', function() {
    this.value = this.value.slice(0, this.maxLength);
});

// DESABILITAR SCROLL EM INPUTS TIPO NÚMERO

$('input[type=number]').on('wheel', function(e) {
    e.preventDefault();
});

// MOSTRAR/OCULTAR SENHA

$(document).on('click', '.unmask', function() {
    const input = $(this).prev('input');
    const newType = input.attr('type') === 'password' ? 'text' : 'password';
    input.attr('type', newType);
});

// PERDER O FOCO APÓS CLIQUE NO BOTÃO

$(document).on("click", ".button", function() {
  this.blur(); // MÉTODO NATIVO PARA PERDER FOCO
});

// IMPEDIR ENTER NO #ADD-PRODUCT-TRIGGER

$('#add-product-trigger').on('keydown', function(e) {
  if (e.key === "Enter") {
      e.preventDefault();
  }
});